package frontpart;

public class Rules_db {

}
